import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import loginImage from "./assets/Loginsplit.jpg"; // make sure this image is in src/assets

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    if (!email || !password) {
      alert("Please enter both email and password.");
      return;
    }

    fetch("http://localhost/court-case-api/login.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.error) {
          alert(data.error);
        } else {
          localStorage.setItem("user", JSON.stringify(data));
          const role = data.role;
          if (role === "user") navigate("/user");
          else if (role === "clerk") navigate("/clerk");
          else if (role === "lawyer") navigate("/lawyer");
          else if (role === "judge") navigate("/judge");
        }
      })
      .catch((err) => {
        console.error("Login failed:", err);
        alert("Login failed. Please try again.");
      });
  };

  return (
    <div className="login-page">
      <div
        className="login-image-side"
        style={{ backgroundImage: `url(${loginImage})` }}
      />
      <div className="login-form-side">
        <form className="login-box" onSubmit={handleLogin}>
          <h2></h2>
          <p className="subtitle">Sign in to your account</p>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button type="submit" className="button">Login</button>
        </form>
      </div>
    </div>
  );
}

export default Login;
