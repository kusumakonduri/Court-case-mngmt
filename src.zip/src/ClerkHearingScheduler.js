import { useState } from "react";

function ClerkHearingScheduler({ caseData, onScheduled }) {
  const [hearingDate, setHearingDate] = useState("");

  const handleSchedule = () => {
    if (!hearingDate) {
      alert("Please select a date/time");
      return;
    }

    fetch("http://localhost/court-case-api/schedule_hearing.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_id: caseData.id, hearing_date: hearingDate }),
    })
      .then(res => res.json())
      .then(data => {
        alert(data.message || data.error);
        onScheduled();
      });
  };

  return (
    <div className="case-card">
      <strong>{caseData.title}</strong>
      <p>{caseData.description}</p>
      <label>Hearing Date/Time:</label>
      <input
        type="datetime-local"
        value={hearingDate}
        onChange={(e) => setHearingDate(e.target.value)}
      />
      <br />
      <button onClick={handleSchedule}>Schedule Hearing</button>
    </div>
  );
}

export default ClerkHearingScheduler;
