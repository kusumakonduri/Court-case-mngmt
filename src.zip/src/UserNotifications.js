import { useEffect, useState } from "react";
import './UserDashboard.css';

function UserNotifications() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [notifs, setNotifs] = useState([]);

  const load = () => {
    fetch(`http://localhost/court-case-api/get_notifications.php?user_id=${user.id}`)
      .then(res => res.json())
      .then(data => setNotifs(data));
  };

  useEffect(() => {
    load();
  }, []);

  const dismiss = (id) => {
    fetch("http://localhost/court-case-api/delete_notification.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    })
      .then(res => res.json())
      .then(data => {
        alert(data.message);
        load();
      });
  };

  return (
    <div className="main-content">
      <h2>🔔 Notifications</h2>
      {notifs.length === 0 ? (
        <p>No notifications right now.</p>
      ) : (
        notifs.map(n => (
          <div key={n.id} className="case-card">
            <p>{n.message}</p>
            <small style={{ color: "#999" }}>{new Date(n.uploaded_at).toLocaleString()}</small>
            <br />
            <button onClick={() => dismiss(n.id)} style={{ marginTop: "10px" }}>
              Dismiss
            </button>
          </div>
        ))
      )}
    </div>
  );
}

export default UserNotifications;
