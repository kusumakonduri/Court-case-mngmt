import { useState, useEffect } from "react";
import './UserDashboard.css';

function UserDashboard() {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    date_filed: "",
  });

  const [cases, setCases] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [activeTab, setActiveTab] = useState("file");
  const user = JSON.parse(localStorage.getItem("user"));

  useEffect(() => {
    fetch(`http://localhost/court-case-api/get_user_cases.php?filed_by=${user.id}`)
      .then((res) => res.json())
      .then((data) => setCases(data));

    fetch(`http://localhost/court-case-api/get_notifications.php?user_id=${user.id}`)
      .then((res) => res.json())
      .then((data) => setNotifications(data));
  }, [user.id]);

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch("http://localhost/court-case-api/add_case.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...formData, filed_by: user.id }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.error) alert(data.error);
        else {
          alert("Case filed successfully!");
          window.location.reload();
        }
      });
  };

  const dismissNotification = (id) => {
    fetch("http://localhost/court-case-api/mark_notification_read.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    })
      .then((res) => res.json())
      .then(() => {
        setNotifications((prev) =>
          prev.filter((notif) => notif.id !== id)
        );
      });
  };

  return (
    <div className="user-dashboard-layout">
      <aside className="sidebar">
        <h3>{user.name}</h3>
        <ul>
          <li onClick={() => setActiveTab("file")} className={activeTab === "file" ? "active" : ""}>📄 File Case</li>
          <li onClick={() => setActiveTab("cases")} className={activeTab === "cases" ? "active" : ""}>📁 My Cases</li>
          <li onClick={() => setActiveTab("notifs")} className={activeTab === "notifs" ? "active" : ""}>🔔 Notifications ({notifications.length})</li>
        </ul>
      </aside>

      <main className="main-content">
        <h2>User Dashboard</h2>

        {activeTab === "file" && (
          <div className="section">
            <h3>File a New Case</h3>
            <form onSubmit={handleSubmit}>
              <input name="title" placeholder="Case Title" onChange={handleChange} /><br />
              <textarea name="description" placeholder="Case Description" onChange={handleChange}></textarea><br />
              <input type="date" name="date_filed" onChange={handleChange} /><br />
              <button type="submit">File Case</button>
            </form>
          </div>
        )}

        {activeTab === "cases" && (
          <div className="section">
            <h3>My Filed Cases</h3>
            <ul className="case-list">
              {cases.map(c => (
                <li key={c.id}>
                  <strong>{c.title}</strong><br />
                  <em>Date:</em> {c.date_filed}<br />
                  <p>{c.description}</p>
                  {c.verdict && (
                    <div className="verdict-box">
                      <strong>Verdict:</strong><br />
                      {c.verdict}
                    </div>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}

        {activeTab === "notifs" && (
          <div className="section">
            <h3>Notifications</h3>
            {notifications.length === 0 ? (
              <p>No new notifications.</p>
            ) : (
              <ul className="notif-list">
                {notifications.map((n) => (
                  <li key={n.id}>
                    📣 {n.message}
                    <br />
                    <small>{new Date(n.created_at).toLocaleString()}</small><br />
                    <button
                      onClick={() => dismissNotification(n.id)}
                      className="dismiss-btn"
                    >
                      Dismiss
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default UserDashboard;
