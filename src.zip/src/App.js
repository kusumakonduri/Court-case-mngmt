import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './Login';
import JudgeDashboard from './JudgeDashboard';
import LawyerDashboard from './LawyerDashboard';
import ClerkDashboard from './ClerkDashboard';
import UserDashboard from './UserDashboard';
import ClerkHearingScheduler from './ClerkHearingScheduler';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/judge" element={<JudgeDashboard />} />
        <Route path="/lawyer" element={<LawyerDashboard />} />
        <Route path="/clerk" element={<ClerkDashboard />} />
        <Route path="/clerk/schedule" element={<ClerkHearingScheduler />} />
        <Route path="/user" element={<UserDashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
