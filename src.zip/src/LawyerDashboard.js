import { useState, useEffect } from "react";
import './UserDashboard.css'; // Reuse CSS for layout & styles

function FileList({ caseId, user }) {
  const [files, setFiles] = useState([]);

  useEffect(() => {
    loadFiles(caseId);
  }, [caseId]);

  const loadFiles = () => {
    fetch(`http://localhost/court-case-api/get_case_files.php?case_id=${caseId}`)
      .then(res => res.json())
      .then(data => setFiles(data));
  };

  return (
    <div>
      <h4>Uploaded Files</h4>
      {files.length === 0 ? (
        <p>No files uploaded.</p>
      ) : (
        <ul>
          {files.map(f => (
            <li key={f.id}>
              <a href={`http://localhost/court-case-api/${f.file_path}`} target="_blank" rel="noreferrer">
                {f.file_path.split('/').pop()}
              </a>
              {f.uploaded_by === user.id && (
                <>
                  &nbsp;|&nbsp;
                  <button
                    onClick={() => {
                      if (window.confirm("Delete this file?")) {
                        fetch("http://localhost/court-case-api/delete_file.php", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ file_id: f.id }),
                        })
                          .then((res) => res.json())
                          .then(() => loadFiles());
                      }
                    }}
                  >
                    Delete
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function LawyerDashboard() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [cases, setCases] = useState([]);
  const [activeTab, setActiveTab] = useState("assigned");

  useEffect(() => {
    fetch(`http://localhost/court-case-api/get_lawyer_cases.php?lawyer_id=${user.id}`)
      .then(res => res.json())
      .then(data => setCases(data));
  }, [user.id]);

  return (
    <div className="user-dashboard-layout">
      <aside className="sidebar">
        <h3>{user.name}</h3>
        <ul>
          <li onClick={() => setActiveTab("assigned")} className={activeTab === "assigned" ? "active" : ""}>📂 Assigned Cases</li>
        </ul>
      </aside>

      <main className="main-content">
        <h2>Lawyer Dashboard</h2>

        {activeTab === "assigned" && (
          <div className="section">
            {cases.length === 0 ? (
              <p>No assigned cases yet.</p>
            ) : (
              cases.map((c) => (
                <div key={c.id} className="case-card">
                  <strong>{c.title}</strong>
                  <p>{c.description}</p>
                  <p><em>Filed by:</em> {c.filed_by_name}</p>
                  <p><em>Date:</em> {c.date_filed}</p>

                  {c.verdict ? (
                    <div className="verdict-box">
                      <strong>Verdict:</strong><br />
                      {c.verdict}
                    </div>
                  ) : (
                    <p style={{ color: "gray" }}><em>No verdict submitted yet.</em></p>
                  )}

                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      const fileInput = document.getElementById(`file-${c.id}`);
                      const formData = new FormData();
                      formData.append("file", fileInput.files[0]);
                      formData.append("case_id", c.id);
                      formData.append("uploaded_by", user.id);

                      fetch("http://localhost/court-case-api/upload_file.php", {
                        method: "POST",
                        body: formData,
                      })
                        .then((res) => res.json())
                        .then((data) => {
                          alert(data.message || data.error);
                          e.target.reset();
                        });
                    }}
                  >
                    <input type="file" id={`file-${c.id}`} required />
                    <button type="submit">Upload File</button>
                  </form>

                  <FileList caseId={c.id} user={user} />
                </div>
              ))
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default LawyerDashboard;
