import { useState, useEffect } from "react";
import './JudgeDashboard.css'; // we’ll make this next

function JudgeDashboard() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [cases, setCases] = useState([]);
  const [activeTab, setActiveTab] = useState("assigned");

  useEffect(() => {
    fetch(`http://localhost/court-case-api/get_judge_cases.php?judge_id=${user.id}`)
      .then(res => res.json())
      .then(data => setCases(data));
  }, [user.id]);

  const submitVerdict = (caseId) => {
    const input = document.getElementById(`verdict-${caseId}`);
    const verdict = input.value.trim();

    if (!verdict) {
      alert("Please enter a verdict before submitting.");
      return;
    }

    fetch("http://localhost/court-case-api/submit_verdict.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_id: caseId, verdict }),
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.message || data.error);
        window.location.reload();
      });
  };

  return (
    <div className="user-dashboard-layout">
      <aside className="sidebar">
        <h3>{user.name}</h3>
        <ul>
          <li
            onClick={() => setActiveTab("assigned")}
            className={activeTab === "assigned" ? "active" : ""}
          >
            📂 Assigned Cases
          </li>
        </ul>
      </aside>

      <main className="main-content">
        <h2>Judge Dashboard</h2>

        {activeTab === "assigned" && (
          <div className="section">
            {cases.length === 0 ? (
              <p>No assigned cases.</p>
            ) : (
              cases.map((c) => (
                <div key={c.id} className="case-card">
                  <strong>{c.title}</strong>
                  <p>{c.description}</p>
                  <p><em>Filed by:</em> {c.filed_by_name}</p>
                  <p><em>Hearing:</em> {c.hearing_date || "Not scheduled"}</p>
                  <p><em>Verdict:</em> {c.verdict || "Pending"}</p>

                  {c.verdict === null && (
                    <>
                      <textarea
                        id={`verdict-${c.id}`}
                        placeholder="Write your verdict..."
                        style={{ width: "100%", height: "80px", marginTop: "10px" }}
                      ></textarea>
                      <br />
                      <button onClick={() => submitVerdict(c.id)}>
                        Submit Verdict
                      </button>
                    </>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default JudgeDashboard;
