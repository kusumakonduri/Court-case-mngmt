import { useEffect, useState } from "react";
import './ClerkDashboard.css';
import ClerkHearingScheduler from './ClerkHearingScheduler';

function ClerkDashboard() {
  const user = JSON.parse(localStorage.getItem("user"));
  const [unassignedCases, setUnassignedCases] = useState([]);
  const [assignedCases, setAssignedCases] = useState([]);
  const [judges, setJudges] = useState([]);
  const [lawyers, setLawyers] = useState([]);
  const [activeTab, setActiveTab] = useState("unassigned");
  const [stats, setStats] = useState({
    total_cases: 0,
    unassigned_cases: 0,
    assigned_cases: 0,
    scheduled_hearings: 0,
  });

  const loadData = () => {
    fetch("http://localhost/court-case-api/get_unassigned_cases.php")
      .then(res => res.json())
      .then(data => setUnassignedCases(data));

    fetch("http://localhost/court-case-api/get_assigned_cases.php")
      .then(res => res.json())
      .then(data => setAssignedCases(data));
  };

  const loadStats = () => {
    fetch("http://localhost/court-case-api/get_case_stats.php")
      .then(res => res.json())
      .then(data => setStats(data));
  };

  useEffect(() => {
    loadData();
    loadStats();
  }, []);

  const assign = (caseId) => {
    const judgeId = document.getElementById(`judge-${caseId}`).value;
    const lawyerId = document.getElementById(`lawyer-${caseId}`).value;

    if (!judgeId || !lawyerId) {
      alert("Please select both judge and lawyer!");
      return;
    }

    fetch("http://localhost/court-case-api/assign_case.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ case_id: caseId, judge_id: judgeId, lawyer_id: lawyerId }),
    })
      .then(res => res.json())
      .then(data => {
        alert(data.message || data.error);
        loadData();
        loadStats();
      });
  };

  return (
    <div className="user-dashboard-layout">
      <aside className="sidebar">
        <h3>{user.name}</h3>
        <ul>
          <li onClick={() => setActiveTab("unassigned")} className={activeTab === "unassigned" ? "active" : ""}>📝 Unassigned Cases</li>
          <li onClick={() => setActiveTab("schedule")} className={activeTab === "schedule" ? "active" : ""}>📅 Schedule Hearings</li>
        </ul>
      </aside>

      <main className="main-content">
        <h2>Clerk Dashboard</h2>

        <div className="stats-cards">
          <div className="stat-card">
            <h4>Total Cases</h4>
            <p>{stats.total_cases}</p>
          </div>
          <div className="stat-card">
            <h4>Unassigned</h4>
            <p>{stats.unassigned_cases}</p>
          </div>
          <div className="stat-card">
            <h4>Assigned</h4>
            <p>{stats.assigned_cases}</p>
          </div>
          <div className="stat-card">
            <h4>Scheduled</h4>
            <p>{stats.scheduled_hearings}</p>
          </div>
        </div>

        {activeTab === "unassigned" && (
          <div className="section">
            {unassignedCases.length === 0 ? (
              <p>No unassigned cases.</p>
            ) : (
              unassignedCases.map(c => (
                <div key={c.id} className="case-card">
                  <strong>{c.title}</strong>
                  <p>{c.description}</p>

                  <label>Assign Judge:</label>
                  <select id={`judge-${c.id}`} defaultValue="">
                    <option value="" disabled>-- Select Judge --</option>
                    {judges.map(j => (
                      <option key={j.id} value={j.id}>{j.name}</option>
                    ))}
                  </select>

                  <label>Assign Lawyer:</label>
                  <select id={`lawyer-${c.id}`} defaultValue="">
                    <option value="" disabled>-- Select Lawyer --</option>
                    {lawyers.map(l => (
                      <option key={l.id} value={l.id}>{l.name}</option>
                    ))}
                  </select>

                  <button onClick={() => assign(c.id)}>Assign</button>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === "schedule" && (
          <div className="section">
            <h3>Schedule Hearing</h3>

            {assignedCases.filter(c => !c.hearing_date).length === 0 ? (
              <p>No cases to schedule.</p>
            ) : (
              assignedCases
                .filter(c => !c.hearing_date)
                .map((c) => (
                  <ClerkHearingScheduler
                    key={c.id}
                    caseData={c}
                    onScheduled={() => {
                      loadData();
                      loadStats();
                    }}
                  />
                ))
            )}
          </div>
        )}
      </main>
    </div>
  );
}

export default ClerkDashboard;
